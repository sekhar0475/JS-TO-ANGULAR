var App = angular.module('myApp', ['ngRoute', 'ngMaterial']);
//ngModule.constant('moment', require('moment-timezone'));
App.config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {

  $routeProvider
  //  .when('/', {
  //       controller: 'homeCtrl',
  //       templateUrl: 'Public/views/home.html'
  //   })
    .when('/deviceview', {
      templateUrl: 'Public/views/deviceview.html',
      controller: 'deviceViewCtrl'
    }).when('/acuidesign', {
      templateUrl: 'Public/views/acuidesign.html',
      controller: 'acuidesignCtrl'
    }).when('/ceiling', {
      templateUrl: 'Public/views/ceilinguidesign.html',
      controller: 'ceilinguidesignCtrl'
    }).when('/home', {
      templateUrl: 'Public/views/home.html',
      controller: 'homeCtrl'
    }).when('/light', {
      templateUrl: 'Public/views/tuyalight.html',
      controller: 'tuyalightCtrl'
    }).when('/camera', {
      templateUrl: 'Public/views/tuyacamera.html',
      controller: 'tuyacameraCtrl'
    }).when('/profileview', {
      templateUrl: 'Public/views/info.html',
      controller: 'infoCtrl'
    }).when('/notifications', {
      templateUrl: 'Public/views/notifications.html',
      controller: 'notificationsCtrl'
    });
    // .otherwise({ redirectTo: '/'});
}]);


//MainController
App.filter('round', function () {
  return function (value, mult, dir) {

    dir = dir || 'nearest';
    mult = mult || 1;

    value = !value ? 0 : Number(value);

    if (dir === 'up') {

      return Math.ceil(value / mult) * mult;

    } else if (dir === 'down') {

      return Math.floor(value / mult) * mult;

    } else {

      return Math.round(value / mult) * mult;

    }
  };
});

App.filter('onlineFilter', function () {
  return function (x) {
    $scope.localAdminUserHub = JSON.parse(localStorage.getItem('localAdminUserHub'));
  };
});

App.controller('homeCtrl', function ($scope, $filter, $http, $interval, $timeout, $window, $location) {
  $scope.MainTempValue = { temp: "--", min: "--", max: "--", city: "--", icon: "04d", temp_1: "--", time_1: "--", icon_1: "04d", temp_2: "--", time_2: "--", icon_2: "04d", temp_3: "--", time_3: "--", icon_3: "04d" };

  $scope.getWetherData = function () {
    $http.post("https://jptest.livesmart.co.jp/ai/v3/getWeather", { lat: '35.69', lon: '139.692' })
      .then(function (response) {
        //debugger;
        if (response.data.status == 1) {
          console.log("data:", response.data);
          $scope.WetherRespond = response.data.data;
          $scope.MainTempValue.temp = (parseFloat($scope.WetherRespond.current.main.temp) - 273.15).toFixed(1);
          $scope.MainTempValue.icon = $scope.WetherRespond.current.weather[0].icon;
          $scope.MainTempValue.min = (parseFloat($scope.WetherRespond.current.main.temp_min) - 273.15).toFixed(0);
          $scope.MainTempValue.max = (parseFloat($scope.WetherRespond.current.main.temp_max) - 273.15).toFixed(0);
          $scope.MainTempValue.city = $scope.WetherRespond.current.name;
          $scope.MainTempValue.temp1 = (parseFloat($scope.WetherRespond.hourly.list[0].main.temp) - 273.15).toFixed(0);
          $scope.MainTempValue.temp2 = (parseFloat($scope.WetherRespond.hourly.list[1].main.temp) - 273.15).toFixed(0);
          $scope.MainTempValue.temp3 = (parseFloat($scope.WetherRespond.hourly.list[2].main.temp) - 273.15).toFixed(0);
          $scope.MainTempValue.time1 = new Date(new Date($scope.WetherRespond.hourly.list[0].dt_txt).getTime() + (9 * 60 * 60 * 1000));
          $scope.MainTempValue.time2 = new Date(new Date($scope.WetherRespond.hourly.list[1].dt_txt).getTime() + (9 * 60 * 60 * 1000));
          $scope.MainTempValue.time3 = new Date(new Date($scope.WetherRespond.hourly.list[2].dt_txt).getTime() + (9 * 60 * 60 * 1000));
          $scope.MainTempValue.icon_1 = $scope.WetherRespond.list[0].weather[0].icon;
          $scope.MainTempValue.icon_2 = $scope.WetherRespond.list[1].weather[0].icon;
          $scope.MainTempValue.icon_3 = $scope.WetherRespond.list[2].weather[0].icon;
        }
      })

  }


  $scope.getWetherData();
});





App.controller('infoCtrl', function ($scope, $filter, $http, $interval, $timeout, $window, $location) {
  $scope.urlBase = 'https://jptest.livesmart.co.jp';
  localStorage.setItem("localurlBase", JSON.stringify($scope.urlBase));
  $scope.localurlBase = JSON.parse(localStorage.getItem('localurlBase'));
  $scope.localuserinfo = {};
  $scope.app_device_token_id = 'LineWebRemote';
  var urlToParse = $location.search();
  $scope.webToken = 'weburl_' + urlToParse.token_id;
  $scope.sessionstatus = function () {
    $scope.loginAlertMessage = false;
    if ($scope.webToken != undefined) {
      $http.post($scope.localurlBase + '/webcontrol/v1/getTokenData', {
        'token': $scope.webToken
      })
        .then(function (response) {
          //debugger;
          console.log("session response :" + JSON.stringify(response.data));
          if (response.status == 200) {
            $scope.sessionstatusval = response.data.status;
            $scope.sessionmsg = response.data.message;
           

            if ($scope.sessionstatusval == 1) {
              $scope.user_type = response.data.data.user_type;
              console.log("user type",$scope.user_type)
              localStorage.setItem("LineSessionDetails", JSON.stringify(response.data.data));
              $scope.localuserinfo = JSON.parse(localStorage.getItem('LineSessionDetails'));
              $scope.getProfileDetails();
            } else {
              $scope.loginAlertMessage = false;
              $scope.notiError = true;
              $scope.notiErrorshow = false;
              $scope.notiErrorMessage = $scope.sessionmsg;
            }
          } else {
            $scope.loginAlertMessage = false;
            $scope.notiError = true;
            $scope.notiErrorshow = false;
            $scope.notiErrorMessage = "Server Error Please try agan later...";
          }
        });

    }
    else {
      $scope.loginAlertMessage = false;
      $scope.notiError = true;
      $scope.notiErrorshow = false;
      $scope.notiErrorMessage = "Invalid Request. Please try agan later...";

    }

  }
  $scope.sessionstatus();

$scope.getProfileDetails=function(){
  $http.post($scope.localurlBase + '/user/v3/getUserProfile', {
    'user_id': $scope.localuserinfo.user_id,
    'app_device_token_id': 'LineWebRemote',
    'origin_id': 15,
    'wtoken_id': $scope.webToken,
    'source': 'webLine'
    
  })
    .then(function (response) {
     
console.log("user profile information",JSON.stringify(response.data))
if(response.data.status == 1){
$scope.user_info = response.data.user;
console.log($scope.user_info)
if( $scope.user_type == "master"){

 $scope.name = $scope.user_info.first_name + " " + $scope.user_info.last_name;
 $scope.dob = $scope.user_info.dob;
 $scope.gender = $scope.user_info.gender;
 $scope.email = $scope.user_info.email_id;
 $scope.phone = $scope.user_info.phone_no;

}
else{
  $scope.name = $scope.user_info.first_name + " " + $scope.user_info.last_name;
  $scope.dob = $scope.user_info.dob;
  $scope.gender = $scope.user_info.gender;
  $scope.email = $scope.user_info.email_id;
  $scope.phone = $scope.user_info.email_phone;
}

}
else{
  $scope.loginAlertMessage = false;
  $scope.notiError = true;
  $scope.notiErrorshow = false;
  $scope.notiErrorMessage = response.data.message;
}

  })
  
}
 

});


App.controller('notificationsCtrl', function ($scope, $filter, $http, $interval, $timeout, $window, $location) {
  
  $scope.urlBase = 'https://jptest.livesmart.co.jp';
  localStorage.setItem("localurlBase", JSON.stringify($scope.urlBase));
  $scope.localurlBase = JSON.parse(localStorage.getItem('localurlBase'));
  $scope.localuserinfo = {};
  $scope.DeviceDetails=[];
  $scope.app_device_token_id = 'LineWebRemote';
  var urlToParse = $location.search();
  $scope.webToken = 'weburl_' + urlToParse.token_id;
  $scope.sessionstatus = function () {
    $scope.loginAlertMessage = false;
    if ($scope.webToken != undefined) {
      $http.post($scope.localurlBase + '/webcontrol/v1/getTokenData', {
        'token': $scope.webToken
      })
        .then(function (response) {
          //debugger;
          console.log("session response :" + JSON.stringify(response.data));
          if (response.status == 200) {
            $scope.sessionstatusval = response.data.status;
            $scope.sessionmsg = response.data.message;
            if ($scope.sessionstatusval == 1) {
              localStorage.setItem("LineSessionDetails", JSON.stringify(response.data.data));
              $scope.localuserinfo = JSON.parse(localStorage.getItem('LineSessionDetails'));
              $scope.getDeviceDetails();
              $scope.getTimelineDetails();
            } else {
              $scope.loginAlertMessage = false;
              $scope.notiError = true;
              $scope.notiErrorshow = false;
              $scope.notiErrorMessage = $scope.sessionmsg;
            }
          } else {
            $scope.loginAlertMessage = false;
            $scope.notiError = true;
            $scope.notiErrorshow = false;
            $scope.notiErrorMessage = "Server Error Please try agan later...";
          }
        });

    }
    else {
      $scope.loginAlertMessage = false;
      $scope.notiError = true;
      $scope.notiErrorshow = false;
      $scope.notiErrorMessage = "Invalid Request. Please try agan later...";

    }

  }
  $scope.sessionstatus();


 $scope.ActyMessage=[]
 $scope.NotiMessage=[]
  $scope.timeline_messages=[];
  $scope.getDeviceDetails=function(){ 
    $http.post($scope.localurlBase + '/device/getDevices ', {
      'user_id': $scope.localuserinfo.user_id,
      'app_device_token_id': 'LineWebRemote',
      'origin_id': 15,
      'hub_id': $scope.localuserinfo.hub_id,
      'wtoken_id': $scope.webToken,
      'source': 'webLine'
    })
      .then(function (response) {
        if(response.data.status==1){
          $scope.DeviceDetails.length=0;
          $scope.DeviceDetails = response.data.devices
        }
      })
  }
  $scope.getTimelineDetails=function(){
    
    $http.post($scope.localurlBase + '/event/getTimeLineData ', {
      'user_id': $scope.localuserinfo.user_id,
      'app_device_token_id': 'LineWebRemote',
      'origin_id': 15,
      'hub_id': $scope.localuserinfo.hub_id,
      'wtoken_id': $scope.webToken,
      'source': 'webLine',
      'device_b_one_id':'TIMELINE',
      'onlyModified':false,
      'count':"100"
      
    })
      .then(function (response) {
        $scope.ActyMessage.length=0
        $scope.NotiMessage.length=0
        if(response.data.status == 1){

      
        $scope.timeline_messages = response.data.data
        _.each( $scope.timeline_messages, function (currentElem) {
          var timeStamp=new Date(currentElem.timestamp).toLocaleDateString();
          if(currentElem.device_b_one_id == "ACTY"){
            if($scope.ActyMessage.length>0)
            {
              var ActyData=_.where($scope.ActyMessage, {title:timeStamp})
              console.log("Data  Value: ",JSON.stringify(ActyData)+" Time Stamp:"+timeStamp)
              if(ActyData.length>0){
                var Index=_.findLastIndex($scope.ActyMessage, {title: timeStamp});
                $scope.ActyMessage[Index].message.push(currentElem);
              }
              else
            {
              var Data={title:timeStamp,message:[]};
              Data.message.push(currentElem);
              $scope.ActyMessage.push(Data)
            }
              
            }
            else
            {
              var Data={title:timeStamp,message:[]};
              Data.message.push(currentElem);
              $scope.ActyMessage.push(Data)
            }
            
            
          }
          if(currentElem.device_b_one_id == "NOTI"){
            if($scope.NotiMessage.length>0){
              var NotiData=_.where($scope.NotiMessage, {title:timeStamp})
              console.log("Data  Value: ",JSON.stringify(NotiData)+" Time Stamp:"+timeStamp)
              if(NotiData.length>0){
                var Index=_.findLastIndex($scope.NotiMessage, {title: timeStamp});
                $scope.NotiMessage[Index].message.push(currentElem);
              }
              else
              {
                var Data={title:timeStamp,message:[]};
                Data.message.push(currentElem);
                $scope.NotiMessage.push(Data)
              }

            }
            else{
              var Data={title:timeStamp,message:[]};
              Data.message.push(currentElem);
              $scope.NotiMessage.push(Data)
            }
          }
        
      });
      console.log("Notification:",$scope.NotiMessage);
    }
    else{
      $scope.loginAlertMessage = false;
      $scope.notiError = true;
      $scope.notiErrorshow = false;
      $scope.notiErrorMessage = response.data.message;
    }
      })
       
  }
  $scope.getDeviceName=function(b_one_id){
    var Details=_.where($scope.DeviceDetails,{device_b_one_id:b_one_id})
    if(Details.length>0){
      return Details[0].device_name+" "
    }
    else{
      return ""
    }
  }
  $scope.getRoomName=function(b_one_id){
    var Details=_.where($scope.DeviceDetails,{device_b_one_id:b_one_id})
    if(Details.length>0){
      return Details[0].room_name+" "
    }
    else{
      return ""
    }
  }
  $scope.getDateFormate=function(datev){
    var Datevalue=new Date().toLocaleDateString();
    if(datev==Datevalue){
      return "Today"
    }
    else{
      return new Date(datev);
    }
  }


});


App.controller('ceilinguidesignCtrl', function ($scope, $filter, $http, $interval, $timeout, $window, $location) {});

App.controller('tuyalightCtrl', function ($scope, $filter, $http, $interval, $timeout, $window, $location) {
  $scope.invert = 0
  $scope.temperature = false;
  $scope.Saturation = false;
  var s = document.getElementById("sliderRange");
  
  $scope.showTemp =function(){
    $scope.temperature = true;
    $scope.Saturation = false;
    
  }
  $scope.showSat = function(){
    $scope.temperature = false;
    $scope.Saturation = true;
  }
 

  s.addEventListener("input", function () {
    console.log("value:" + s.value);
    $scope.invert=s.value

  })

  var rangeSlider = document.getElementById("rs-range-line");
  var rangeBullet = document.getElementById("rs-bullet");
  rangeBullet.style.left = "12%";
  
  rangeSlider.addEventListener("input", showSliderValue, false);
  
  function showSliderValue() {
    rangeBullet.innerHTML = (rangeSlider.value) + "%";
    rangeBullet.style.left = (12+((60/100)*rangeSlider.value)) + "%";
    if(window.screen.availWidth > 600){
      rangeBullet.style.left = (12+((70/100)*rangeSlider.value)) + "%";
    }
   
  }
  


});


App.controller('tuyacameraCtrl', function ($scope, $filter, $http, $interval, $timeout, $window, $location) {});

App.controller('acuidesignCtrl', function ($scope, $filter, $http, $interval, $timeout, $window, $location) {
  $scope.urlBase = 'https://jptest.livesmart.co.jp';
  var status = { status: 1 };

  /* $http.post($scope.urlBase+"/ai/getAIStaticData",status).then(function(response){
    if(response.data.status==1)
    {
      var dataVal=response.data.data;
      for(var i=0;i<Object.keys(dataVal).length;i++)
      {
        dataVal[i].sort_order=dataVal[i].key;
      }
      console.log("data check value :"+JSON.stringify(dataVal));
    }
  }) */







});
//Main Controller

//----------------------------Device View Controller -----------------------------------------------//
App.controller('deviceViewCtrl', function ($scope, $filter, $http, $interval, $timeout, $window, $location, $mdDialog) {
  $scope.urlBase = 'https://jptest.livesmart.co.jp';
  //debugger;
  localStorage.setItem("localurlBase", JSON.stringify($scope.urlBase));
  $scope.localurlBase = JSON.parse(localStorage.getItem('localurlBase'));

  document.getElementById('ceilingbody').className = "device-card  col-lg-12 col-md-12 col-sm-12 col-xs-12 nopadding clearfix remote-section ac-grad-cool";

  //All User Details Main for HUb ID
  $scope.AiStatusCheck = "2";
  var urlToParse = $location.search();
  $scope.userlogin = {};
  $scope.localuserinfo = {};
  $scope.app_device_token_id = 'LineWebRemote';
  $scope.device_type = "ANDROID";
  $scope.loginError = "false";
  $scope.loginAlertMessage = true;
  $scope.webToken = 'weburl_' + urlToParse.token_id;

  $scope.showAlert = function (msg) {
    $mdDialog.show(
      $mdDialog.alert()
        .clickOutsideToClose(false)
        .textContent(msg)
        .ariaLabel('Alert')
        .ok('OK')
        .targetEvent(this)
    )
  };

  $scope.showAdvanced = function (ev) {
    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'Public/views/dialog1.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose: false,
      fullscreen: false // Only for -xs, -sm breakpoints.
    })
      .then(function (answer) {
        if (answer == "1") {
          $scope.AistatusAddindata();
        }
      }, function () {

      });
  };
  function DialogController($scope, $mdDialog) {
    $scope.hide = function () {
      $mdDialog.hide();
    };

    $scope.cancel = function () {
      $mdDialog.cancel();
    };

    $scope.answer = function (answer) {
      $mdDialog.hide(answer);
    };
  }



  $scope.sessionstatus = function () {
    $scope.loginAlertMessage = false;
    if ($scope.webToken != undefined) {
      $http.post($scope.localurlBase + '/webcontrol/v1/getTokenData', {
        'token': $scope.webToken
      })
        .then(function (response) {
          //debugger;
          console.log("session response :" + JSON.stringify(response.data));
          if (response.status == 200) {
            $scope.sessionstatusval = response.data.status;
            $scope.sessionmsg = response.data.message;
            if ($scope.sessionstatusval == 1) {
              localStorage.setItem("LineSessionDetails", JSON.stringify(response.data.data));
              $scope.localuserinfo = JSON.parse(localStorage.getItem('LineSessionDetails'));
              deviceView();
            } else {
              $scope.loginAlertMessage = false;
              $scope.notiError = true;
              $scope.notiErrorshow = false;
              $scope.notiErrorMessage = $scope.sessionmsg;
            }
          } else {
            $scope.loginAlertMessage = false;
            $scope.notiError = true;
            $scope.notiErrorshow = false;
            $scope.notiErrorMessage = "Server Error Please try agan later...";
          }
        });

    }
    else {
      $scope.loginAlertMessage = false;
      $scope.notiError = true;
      $scope.notiErrorshow = false;
      $scope.notiErrorMessage = "Invalid Request. Please try agan later...";

    }

  }
  $scope.sessionstatus();


  $scope.loginAlertMessage = true;

  function callAtInterval() {
    ////////debugger;
    $scope.deviceLatestStatusView();

  };

  $scope.$on('$destroy', function () {
    //////////debugger;
    $interval.cancel($scope.devicestart);
    $interval.cancel($scope.lightstart);
  });


  $scope.firstdeviceLatestStatusView = function () {



    //debugger;
    //$scope.loginAlertMessage=true;
    $http.post($scope.localurlBase + '/event/getLatestStatusForVoice', {
      'user_id': $scope.localuserinfo.user_id,
      'origin_id': 15,
      'hub_id': $scope.localuserinfo.hub_id,
      'device_b_one_id': $scope.localuserinfo.device_b_one_id
    })
   
      .then(function (response) {
        
        console.log("b1 id",$scope.localuserinfo.device_b_one_id)
        console.log("response",response )
        $scope.singleDeviceStatus = response.data.data;
        console.log("response data",$scope.singleDeviceStatus)
        $scope.singleDeviceStatusMessage = response.data;
        $scope.localallUserActivities = JSON.parse(localStorage.getItem('localallUserActivities'));
        localStorage.setItem('localDeviceLatestStatus', JSON.stringify($scope.singleDeviceStatus));
        if($scope.singleDeviceStatus.remoteData){
          localStorage.setItem('localDeviceLatestStatusRemote', JSON.stringify($scope.singleDeviceStatus.remoteData));
          $scope.remoteData = JSON.parse(localStorage.getItem('localDeviceLatestStatusRemote'));
          $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
          console.log("data check in latest status:" + JSON.stringify($scope.singleDeviceStatus));
          //debugger;
          $http.post($scope.localurlBase + '/event/getLatestStatusForVoice', {
            'user_id': $scope.localuserinfo.user_id,
            'origin_id': 15,
            'hub_id': $scope.localuserinfo.hub_id,
            'reqObject': $scope.reqObject,
            'device_b_one_id': "0000"
          })
            .then(function (response) {
              $scope.singleHubTempStatus = response.data.data;
              console.log("HUb Status:" + JSON.stringify($scope.singleHubTempStatus));
              if (($scope.localDeviceLatestStatus.extender_id) != undefined && ($scope.localDeviceLatestStatus.extender_id).length > 4) {
                $scope.temp_data = $scope.singleHubTempStatus["ls_ext_" + ($scope.localDeviceLatestStatus.extender_id)].temp_value;
              }
              else {
                $scope.temp_data = $scope.singleHubTempStatus.ls_mini.temp_value
              }
              if ($scope.singleHubTempStatus.ls_mini.lux_value && $scope.singleHubTempStatus.ls_mini.lux_value != undefined) {
                if ($scope.singleHubTempStatus.maximum_lux !== undefined && $scope.singleHubTempStatus.minimum_lux !== undefined) {
                  var minandmax = $scope.singleHubTempStatus.maximum_lux - $scope.singleHubTempStatus.minimum_lux
                  var luxperval = (($scope.singleHubTempStatus.ls_mini.lux_value - $scope.singleHubTempStatus.minimum_lux) / minandmax) * 100;
                  if (parseInt(luxperval) > 0 && parseInt(luxperval) < 101) {
                    $scope.luxValueper = luxperval.toFixed(0) + "%";
                  }
                  else if (parseInt(luxperval) < 0) {
                    $scope.luxValueper = 0 + "%";
                  }
                  else {
                    $scope.luxValueper = 100 + "%";
                  }
  
                }
  
              }
            });
        }


        $scope.loginAlertMessage = false;
        $scope.changeState();

      });
  }


  $scope.getDeviceLatestStatus = function () {
    //1. Remote categories

    if ($scope.localClickedDevice.category_id == 'a6f4d4c9-e326-4105-bb7c-152d368cdc5d') {
      //debugger;
      $scope.temp_data = "0.0";
      $scope.notifybutton = 1;
      $scope.layout = 0;
      $scope.uvStatus = "Low";
      $scope.uvValue = 0;
      $scope.offOverlay = false;
      $scope.fanimage = false;
      $scope.cssdesign = "ac-grad-cool";
      $scope.aiimgarrowData = true;
      $scope.aiStatusShow = false;
      $scope.DeviceStatus = {}
      $scope.DeviceStatus.power_mode = "OFF";
      $scope.DeviceStatus.swing = "OFF";
      $scope.DeviceStatus.fan = "0";
      $scope.temp_button = true;
      $scope.mode_button = true;
      $scope.fan_value_fun = function (data) {
        return (parseInt(data) + 1)
      }
      var fan_mode = ["FAN AUTO", "FAN LOW", "FAN MID"];
      var fan_mode_status = [{ "status": "0", fan: "FAN AUTO" }, { "status": "1", fan: "FAN LOW" }, { "status": "2", fan: "FAN MID" }]
      var ac_mode = { "COOL": "1", "AUTO": "0", "DRY": "2", "FAN": "3", "HEAT": "4", "OFF": "5" }
      $scope.acremote = {
        'device_id': $scope.localClickedDevice.category_id
      }
      $scope.checkToggleStatus = function () {
        $scope.dummy = 'true';
      }
      $scope.checkedStatus = function () {
        $scope.dummy = 'true';
      }
      $scope.lightOnStatus = function () {
        $scope.dummy = 'true';
      }



      $scope.statusImage = {
        'status_image': 0
      };
      $scope.sendIR = function (irData) {

        //debugger;
        $scope.loginAlertMessage = true;
        $scope.type_remote = $scope.localDeviceLatestStatus.type_remote;
        if ($scope.type_remote == "fa4c465b-b694-4eb1-8b98-d47d4a3145cf") {
          $scope.reqObject = {
            "remote_key_data": irData
          };
        } else {
          $scope.reqObject = {
            "ac_remote_key_data": irData
          };
        }
        $http.post($scope.localurlBase + '/event/sendEventForBots', {
          'user_id': $scope.localuserinfo.user_id,
          'app_device_token_id': 'LineWebRemote',
          'origin_id': 15,
          'hub_id': $scope.localuserinfo.hub_id,
          'device_b_one_id': $scope.localuserinfo.device_b_one_id,
          'wtoken_id': $scope.webToken,
          'source': 'webLine',
          'reqObject': $scope.reqObject,
        })
          .then(function (response) {
            debugger;
            if (response.data.status == 1) {
              $scope.loginAlertMessage = false;
            }
            else {
              $scope.loginAlertMessage = false;
              $scope.notiError = true;
              $scope.notiErrorshow = false;
              $scope.notiErrorMessage = response.data.message;
            };
          });


      };
      $scope.changeState = function () {
        //debugger;
        var test = $scope.singleDeviceStatus;
        $scope.tempchang = "0";
        $scope.fanchang = "0";
        $scope.swingchan = "0";
        $scope.key_irdata = "";
        $scope.noir = false;

        $scope.remoteTempOff = false;
        $scope.enableKey = {};
        $scope.enableKeyNumber = {};
        $scope.device_b_one_id = $scope.localDeviceLatestStatus.device_b_one_id;


        function getAcMode(mode) {
          var modeObj = "OFF";
          switch (mode) {
            case '0':
              modeObj = "AUTO";
              break;
            case '1':
              modeObj = "COOL";
              break;
            case '2':
              modeObj = "DRY";
              break;
            case '3':
              modeObj = "FAN";
              break;
            case '4':
              modeObj = "HEAT";
              break;
            case '5':
              modeObj = "OFF";
              break;
          }
          console.log("mode : " + modeObj);
          return modeObj

        }
        $scope.getModesForAC = function (type, status) {
          var remoteObj = {};
          var SetObj = {}
          console.log("Device Status:", status + " Type:", type);
          remoteObj.power = $scope.DeviceStatus.power;
          remoteObj.mode = $scope.DeviceStatus.mode;
          remoteObj.swing = $scope.DeviceStatus.swing;
          remoteObj["temp"] = $scope.DeviceStatus.temp;
          remoteObj.fan = fan_mode[$scope.DeviceStatus.fan];
          console.log("req OBJ", remoteObj);
          switch (type) {
            case 1://power
              if (remoteObj.power == "ON") {
                remoteObj.power = "OFF";
                SetObj.previous_mode = ac_mode[remoteObj.mode];
                SetObj.current_mode = "5";
              }
              else {
                remoteObj.power = "ON";
                SetObj.previous_mode = "5";
                remoteObj.mode = getAcMode($scope.DeviceStatus.previous_mode);
                SetObj.current_mode = ac_mode[getAcMode($scope.DeviceStatus.previous_mode)];
                remoteObj.temp = $scope.DeviceStatus["temp_" + (getAcMode($scope.DeviceStatus.previous_mode)).toLowerCase()];
              }
              break;
            case 2://mode
              SetObj.previous_mode = ac_mode[remoteObj.mode];
              remoteObj.mode = status;
              SetObj.current_mode = ac_mode[status];
              remoteObj.temp = $scope.DeviceStatus["temp_" + (status).toLowerCase()];
              break;
            case 3://swing

              remoteObj.swing = status;
              var lateststatus = ($scope.DeviceStatus.last_status_ac_remote).split(",");
              SetObj.last_status_ac_remote = lateststatus[0] + "," + lateststatus[1] + "," + lateststatus[2] + "," + lateststatus[3] + "," + lateststatus[4] + "," + status;

              break;
            case 4://fan
              remoteObj.fan = fan_mode[status];
              var lateststatus = ($scope.DeviceStatus.last_status_ac_remote).split(",");
              SetObj.last_status_ac_remote = lateststatus[0] + "," + lateststatus[1] + "," + status + "," + lateststatus[3] + "," + lateststatus[4] + "," + lateststatus[5];
              break;
            case 5://temp_plus
              remoteObj.temp = "" + (parseInt($scope.DeviceStatus.temp) + 1);
              SetObj["temp_" + (remoteObj.mode).toLowerCase()] = remoteObj.temp;
              break;
            case 6://temp_min
              remoteObj.temp = "" + (parseInt($scope.DeviceStatus.temp) - 1);
              SetObj["temp_" + (remoteObj.mode).toLowerCase()] = remoteObj.temp;
              break;
          }
          if (remoteObj.power == "OFF") {
            remoteObj = { power: "OFF" };
          }
          $scope.remoteData = JSON.parse(JSON.parse(localStorage.getItem('localDeviceLatestStatusRemote')));
          console.log("remote Obj:", remoteObj, " Set Status:", SetObj);
          var IRkeydata = _.where($scope.remoteData, remoteObj);
          console.log("IR DATA VALUE:", IRkeydata);
          if (IRkeydata.length == 0) {
            if (type == 2) {
              var reqObj = remoteObj;
              delete reqObj.swing;
              IRkeydata = _.where($scope.remoteData, reqObj);
              if (IRkeydata.length == 0) {
                delete reqObj.fan;
                IRkeydata = _.where($scope.remoteData, reqObj);
                if (IRkeydata.length == 0) {
                  return;
                }
                else {
                  var lateststatus = ($scope.DeviceStatus.last_status_ac_remote).split(",");
                  var fanstatus = _.where(fan_mode_status, { "fan": IRkeydata[0].fan })
                  SetObj.last_status_ac_remote = lateststatus[0] + "," + lateststatus[1] + "," + fanstatus[0].status + "," + lateststatus[3] + "," + lateststatus[4] + "," + lateststatus[5];
                  $scope.remoteSendEvent(IRkeydata[0], SetObj)
                }
              }
              else {
                var lateststatus = ($scope.DeviceStatus.last_status_ac_remote).split(",");
                SetObj.last_status_ac_remote = lateststatus[0] + "," + lateststatus[1] + "," + lateststatus[2] + "," + lateststatus[3] + "," + lateststatus[4] + "," + IRkeydata[0].swing;
                $scope.remoteSendEvent(IRkeydata[0], SetObj)
              }

            }
            else {
              return;
            }
          }
          else {
            $scope.remoteSendEvent(IRkeydata[0], SetObj)
          }
        }
        $scope.remoteArrayData = $scope.remoteData;
        //console.log("remote remote data: " + $scope.remoteData);
        //debugger;
        //If Custom Remote
        if ($scope.localDeviceLatestStatus.type_remote == 'fa4c465b-b694-4eb1-8b98-d47d4a3145cf') {

          $scope.customACRemote = true;
          $scope.remoreIrKey = {};
          //debugger;
          function irKeyLoop() {
            //debugger;
            for (var i = 0; i < ($scope.remoteArrayData).length; i++) {
              $scope.key_number = $scope.remoteArrayData[i].key_number;
              $scope.enableKeyNumber[$scope.key_number] = $scope.remoteArrayData[i].key_number;
              $scope.enableKey[$scope.key_number] = $scope.remoteArrayData[i].key_name;
              $scope.remoreIrKey[$scope.key_number] = $scope.remoteArrayData[i].key_irdata;
            };
          };
          irKeyLoop();
        };
        //If Custom Remote ends
        //If not Custom Remote

        if ($scope.localDeviceLatestStatus.type_remote != 'fa4c465b-b694-4eb1-8b98-d47d4a3145cf') {
          $scope.customACRemote = false;
          var deviceStatus = $scope.localDeviceLatestStatus;
          var mode = getAcMode(deviceStatus.current_mode);
          $scope.DeviceStatus.mode = mode
          var swingfan = (deviceStatus.last_status_ac_remote).split(",");
          $scope.DeviceStatus.previous_mode = deviceStatus.previous_mode;
          $scope.DeviceStatus.swing = swingfan[5];
          $scope.DeviceStatus.fan = swingfan[2];
          $scope.DeviceStatus.last_status_ac_remote = deviceStatus.last_status_ac_remote;
          $scope.DeviceStatus['temp_cool'] = deviceStatus["temp_cool"];
          $scope.DeviceStatus['temp_dry'] = deviceStatus["temp_dry"];
          $scope.DeviceStatus['temp_heat'] = deviceStatus["temp_heat"];
          $scope.DeviceStatus['temp_auto'] = deviceStatus["temp_auto"];
          $scope.DeviceStatus['temp_fan'] = deviceStatus["temp_fan"];
          $scope.DeviceStatus.power = "OFF";
          if (mode != "OFF") {
            $scope.DeviceStatus.power_mode = mode;
            $scope.DeviceStatus.power = "ON";
            $scope.DeviceStatus['temp'] = deviceStatus["temp_" + ((mode).toLowerCase())];
            $scope.mode_button = false;
            if (_.contains(["COOL", "HEAT"], mode)) {
              $scope.temp_button = false;
            }
            else {
              $scope.temp_button = true;
            }

          }
          else {
            $scope.DeviceStatus.power_mode = "off";
            $scope.DeviceStatus.mode = getAcMode(deviceStatus.previous_mode);
            $scope.DeviceStatus['temp'] = deviceStatus["temp_" + ((getAcMode(deviceStatus.previous_mode)).toLowerCase())];
            $scope.mode_button = true;
            $scope.temp_button = true;
          }
          console.log("AC STATUS DATA:" + JSON.stringify($scope.DeviceStatus));

          $scope.remoteSendEvent = function (IrDATA, SetObj) {

            $scope.loginAlertMessage = true;
            //debugger;
            $scope.type_remote = $scope.localDeviceLatestStatus.type_remote;
            if ($scope.type_remote == 'fa4c465b-b694-4eb1-8b98-d47d4a3145cf') {
              $scope.reqObject = {
                "remote_key_data": IrDATA.key_irdata
              };
            } else {
              $scope.reqObject = {
                "ac_remote_key_data": IrDATA.key_irdata
              };
            }
            if ($scope.localDeviceLatestStatus.extender_id != undefined && ($scope.localDeviceLatestStatus.extender_id).length > 6) {
              $scope.reqObject.extender_id = $scope.localDeviceLatestStatus.extender_id
            }
            $http.post($scope.localurlBase + '/event/sendEventForBots', {
              'user_id': $scope.localuserinfo.user_id,
              'app_device_token_id': 'LineWebRemote',
              'origin_id': 15,
              'hub_id': $scope.localuserinfo.hub_id,
              'device_b_one_id': $scope.localuserinfo.device_b_one_id,
              'wtoken_id': $scope.webToken,
              'source': 'webLine',
              'reqObject': $scope.reqObject,
            })
              .then(function (response) {
                console.log("data test check in ac remote" + JSON.stringify(response));
                debugger;

                if (response.data.status == 1) {
                  $scope.remoteSetStatus(SetObj);
                  $scope.loginAlertMessage = false;
                } else {
                  $scope.loginAlertMessage = false;
                  $scope.notiError = true;
                  $scope.notiErrorshow = false;
                  $scope.notiErrorMessage = response.data.message;
                };
              });
          };
          $scope.remoteSetStatus = function (reqObject) {


            console.log("data request:" + JSON.stringify(reqObject));
            //debugger;

            var json = {
              'user_id': $scope.localuserinfo.user_id,
              'app_device_token_id': 'LineWebRemote',
              'origin_id': 15,
              'device_b_one_id': $scope.localuserinfo.device_b_one_id,
              'hub_id': $scope.localuserinfo.hub_id,
              'reqObject': reqObject
            };
            console.log('data for set status value :' + JSON.stringify(json))
            $http.post($scope.localurlBase + '/event/SetStatusForBots', json)
              .then(function (response) {
                //debugger;
                $scope.deviceLatestStatusView();

              });
          };
        };
        //IF not Custome Remote ends

      };
      localStorage.setItem("localDeviceStatus", JSON.stringify($scope.statusImage));
      $scope.checkToggleStatus = function () {
        $scope.dummy = 'true';
      }
      $scope.checkedStatus = function () {
        $scope.dummy = 'true';
      }


      $scope.firstdeviceLatestStatusView();
      $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
      $scope.remoteData = JSON.parse(JSON.parse(localStorage.getItem('localDeviceLatestStatusRemote')));
      //debugger;
      localStorage.setItem("localDevicecategoryId", JSON.stringify($scope.acremote.device_id));
      //Custom Remote
      //console.log("acremode status:" + JSON.stringify($scope.localDeviceLatestStatus));

      var FanMode = _.pluck($scope.remoteData, 'fan');
      console.log("fanemode 0 status:" + JSON.stringify(FanMode));
      var fanModes = _.uniq(FanMode);
      console.log("fanmode status:" + JSON.stringify(fanModes));
      if (_.contains(fanModes, "FAN HI")) {
        fan_mode_status.push({ "status": "3", fan: "FAN HI" })
        fan_mode.push("FAN HI")
      }
      if (_.contains(fanModes, "FAN HIGH")) {
        fan_mode_status.push({ "status": "3", fan: "FAN HIGH" })
        fan_mode.push("FAN HIGH")
      }
      console.log("fan Mode:", fan_mode)
      //debugger;





    }

    //remote category (Except AC)
    //remote category (Except AC)
    else if ($scope.localClickedDevice.category_id == 'd5c6ec14-881a-4d1a-b38d-7139bebeeaa7' || $scope.localClickedDevice
      .category_id == '7edb7e80-cf69-40ce-a63b-408cd4380e70' || $scope.localClickedDevice.category_id ==
      'aa47925c-ba21-4960-b105-de1b67223293' || $scope.localClickedDevice.category_id ==
      'c9df1ead-e06f-4b02-87a4-decc993ec589' || $scope.localClickedDevice.category_id ==
      '9fe678b2-8463-4ac0-9b40-2381ac9e228c' || $scope.localClickedDevice.category_id ==
      '5ad6c717-cda6-45db-9216-9707ea258fe2' || $scope.localClickedDevice.category_id ==
      'b48b63b9-806b-480e-84d4-32d42996c6e1') {

      ////debugger;
      $scope.layout = 0;
      //console.log("data values layout data "+ $scope.layout);
      $scope.notifybutton = 1;

      $scope.uvStatus = "Low";
      $scope.uvValue = 0;
      $scope.offOverlay = false;

      $scope.checkToggleStatus = function () {
        $scope.dummy = 'true';
      }
      $scope.checkedStatus = function () {
        $scope.dummy = 'true';
      }
      $scope.lightOnStatus = function () {
        $scope.dummy = 'true';
      }
      $scope.changeState = function () {
        //debugger;
        var test = $scope.singleDeviceStatus;
        $scope.key_irdata = "";
        $scope.noir = false;
        $scope.remoteTempOff = false;
        $scope.enableKey = {};
        $scope.remoreIrKey = {};
        $scope.device_b_one_id = $scope.localDeviceLatestStatus.device_b_one_id;
        $scope.remoteData = JSON.parse(localStorage.getItem('localDeviceLatestStatusRemote'));

        $scope.remoteArrayData = JSON.parse($scope.remoteData);

        //console.log("remote remote data: " + $scope.remoteData);
        irKeyLoop();

        function irKeyLoop() {
          //debugger;
          for (var i = 0; i < ($scope.remoteArrayData).length; i++) {


            $scope.enableKey[$scope.remoteArrayData[i].key_number] = $scope.remoteArrayData[i].key_number;
            $scope.remoreIrKey[$scope.remoteArrayData[i].key_number] = $scope.remoteArrayData[i];
            //$scope.key = ($scope.remoteArrayData[i].key_name).replace(/ /g, "_");
            //$scope.key = remotekeyValueChanges($scope.key);
            //$scope.enableKey1[$scope.key] = $scope.remoteArrayData[i].key_number;

            // $scope.enableKey.push({
            //   "key_number":$scope.remoteArrayData[i].key_number
            // });
            /*   $scope.key = ($scope.remoteArrayData[i].key_name).replace(/ /g, "_");
              $scope.key = remotekeyValueChanges($scope.key);
              console.log("key value testing : " + $scope.key);
             //debugger;
              $scope.enableKey[$scope.key] = $scope.remoteArrayData[i].key_number;
              $scope.irkey = ($scope.key).replace(/ /g, "_");
              $scope.remoreIrKey[$scope.irkey] = $scope.remoteArrayData[i].key_irdata; */
          };
        };
        // $scope.remoteStatusArray = ($scope.localDeviceLatestStatus.last_status_ac_remote).split(",")
        console.log("Filtered data: " + JSON.stringify($scope.enableKey));
        console.log("Filtered data1: " + JSON.stringify($scope.enableKey1));
      };

      function remotekeyValueChanges(keyvalue) {
        var keyval = keyvalue;
        if (keyval === "VOL_PLUS") {
          keyval = "VOL_UP";
        } else if (keyval === "VOL_MINUS") {
          keyval = "VOL_DOWN";
        } else if (keyval === "CHANNEL_UP") {
          keyval = "CH_UP";
        } else if (keyval === "CHANNEL_DOWN") {
          keyval = "CH_DOWN";
        } else if (keyval === "LEFT_ARROW") {
          keyval = "LEFT";
        } else if (keyval === "RIGHT_ARROW") {
          keyval = "RIGHT";
        } else if (keyval === "UP_ARROW") {
          keyval = "UP";
        } else if (keyval === "DOWN_ARROW") {
          keyval = "DOWN";
        } else if (keyval === "DTH" || keyval === "DVD") {
          keyval = "POWER";
        } else if (keyval === "ZERO") {
          keyval = "0";
        } else if (keyval === "ONE") {
          keyval = "1";
        } else if (keyval === "TWO") {
          keyval = "2";
        } else if (keyval === "THREE") {
          keyval = "3";
        } else if (keyval === "FOUR") {
          keyval = "4";
        } else if (keyval === "FIVE") {
          keyval = "5";
        } else if (keyval === "SIX") {
          keyval = "6";
        } else if (keyval === "SEVEN") {
          keyval = "7";
        } else if (keyval === "EIGHT") {
          keyval = "8";
        } else if (keyval === "NINE") {
          keyval = "9";
        } else if (keyval === "SOUNDMODE") {
          keyval = "SOUND_MODE";
        } else if (keyval === "SOUNDMODE") {
          keyval = "SOUND_MODE";
        } else if (keyval === "CH_ENT") {
          keyval = "CH_ENTER";
        } else if (keyval === "REWIND_BUTTON") {
          keyval = "REW";
        } else if (keyval === "P.MODE") {
          keyval = "PMODE";
        } else if (keyval === "A") {
          keyval = "YELLOW";
        } else if (keyval === "B") {
          keyval = "BLUE";
        } else if (keyval === "C") {
          keyval = "RED";
        } else if (keyval === "D") {
          keyval = "GREEN";
        } else if (keyval === "TITLE") {
          keyval = "SUBTITLE"
        } else if (keyval === "電源") {
          keyval = "POWER"
        }

        return keyval;


      };



      //tv
      if ($scope.localClickedDevice.category_id == 'd5c6ec14-881a-4d1a-b38d-7139bebeeaa7') {
        $scope.tvremote = {
          'device_id': $scope.localClickedDevice.category_id
        };
        localStorage.setItem("localDevicecategoryId", JSON.stringify($scope.tvremote.device_id));
      }
      //Audio Amplifier
      if ($scope.localClickedDevice.category_id == '7edb7e80-cf69-40ce-a63b-408cd4380e70') {
        $scope.audioremote = {
          'device_id': $scope.localClickedDevice.category_id
        };
        localStorage.setItem("localDevicecategoryId", JSON.stringify($scope.audioremote.device_id));
      }
      //Projector
      if ($scope.localClickedDevice.category_id == 'aa47925c-ba21-4960-b105-de1b67223293') {
        $scope.projectorremote = {
          'device_id': $scope.localClickedDevice.category_id
        };
        localStorage.setItem("localDevicecategoryId", JSON.stringify($scope.projectorremote.device_id));
      }
      //Disc Player
      if ($scope.localClickedDevice.category_id == 'c9df1ead-e06f-4b02-87a4-decc993ec589') {
        $scope.discremote = {
          'device_id': $scope.localClickedDevice.category_id
        };
        localStorage.setItem("localDevicecategoryId", JSON.stringify($scope.discremote.device_id));
      }
      //DTH
      if ($scope.localClickedDevice.category_id == '9fe678b2-8463-4ac0-9b40-2381ac9e228c') {
        $scope.dthremote = {
          'device_id': $scope.localClickedDevice.category_id
        };
        localStorage.setItem("localDevicecategoryId", JSON.stringify($scope.dthremote.device_id));
      }
      //Media box
      if ($scope.localClickedDevice.category_id == '5ad6c717-cda6-45db-9216-9707ea258fe2') {
        $scope.mediaboxremote = {
          'device_id': $scope.localClickedDevice.category_id
        };
        localStorage.setItem("localDevicecategoryId", JSON.stringify($scope.mediaboxremote.device_id));
      }
      //Soundbar
      if ($scope.localClickedDevice.category_id == 'b48b63b9-806b-480e-84d4-32d42996c6e1') {
        $scope.soundbarremote = {
          'device_id': $scope.localClickedDevice.category_id
        };
        localStorage.setItem("localDevicecategoryId", JSON.stringify($scope.soundbarremote.device_id));
      }
      $scope.firstdeviceLatestStatusView();
      $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));

      ////debugger;
      //Check Custom Remote
      /* if($scope.localDeviceLatestStatus.type_remote == 'fa4c465b-b694-4eb1-8b98-d47d4a3145cf'){
      $scope.customRemote = true;
      }
      //If not Custom Remote
      if($scope.localDeviceLatestStatus.type_remote != 'fa4c465b-b694-4eb1-8b98-d47d4a3145cf'){
      $scope.customRemote = false;     
      } */
      $scope.statusImage = {
        'status_image': 0
      };


      $scope.setMode = function (irData) {
        console.log("data set mode value: " + JSON.stringify(irData))

        var i = 0;
        if (i == 0) {
          //debugger;
          $scope.loginAlertMessage = true;
          $scope.type_remote = $scope.localDeviceLatestStatus.type_remote;
          if ($scope.type_remote == 'fa4c465b-b694-4eb1-8b98-d47d4a3145cf') {
            $scope.reqObject = {
              "remote_key_data": irData.key_irdata
            };
          } else {
            if (irData.type_remote == undefined) {
              $scope.reqObject = {
                "ac_remote_key_data": irData.key_irdata
              };
            }
            else {
              $scope.reqObject = {
                "remote_key_data": irData.key_irdata
              };
            }

          }

          var jsons = {
            'user_id': $scope.localuserinfo.user_id,
            'app_device_token_id': 'LineWebRemote',
            'origin_id': 15,
            'hub_id': $scope.localuserinfo.hub_id,
            'device_b_one_id': $scope.localuserinfo.device_b_one_id,
            'wtoken_id': $scope.webToken,
            'source': 'webLine',
            'reqObject': $scope.reqObject,
          };
          console.log("data set mode value: " + JSON.stringify(jsons))
          console.log("data set mode value: " + JSON.stringify($scope.localurlBase + '/event/sendEvent'))
          $http.post($scope.localurlBase + '/event/sendEventForBots', jsons)
            .then(function (response) {
              console.log("data set mode value: " + JSON.stringify(response.data))
              //debugger;
              if (response.data.status == 1) {

                $scope.loginAlertMessage = false;
              } else {
                $scope.loginAlertMessage = false;
                $scope.notiError = true;
                $scope.notiErrorshow = false;
                $scope.notiErrorMessage = response.data.message;
              };
            });
        }
      };

    }

    //Custom Remote
    else if ($scope.localClickedDevice.category_id == 'fa4c465b-b694-4eb1-8b98-d47d4a3145cf') {

      // //debugger;
      $scope.notifybutton = 1;
      $scope.layout = 0;
      $scope.uvStatus = "Low";
      $scope.uvValue = 0;
      $scope.offOverlay = false;

      $scope.checkToggleStatus = function () {
        $scope.dummy = 'true';
      }
      $scope.checkedStatus = function () {
        $scope.dummy = 'true';
      }
      $scope.lightOnStatus = function () {
        $scope.dummy = 'true';
      }
      $scope.customremote = {
        'device_id': $scope.localClickedDevice.category_id
      };
      $scope.firstdeviceLatestStatusView();
      $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
      $scope.remoteData = JSON.parse(localStorage.getItem('localDeviceLatestStatusRemote'));;
      // //debugger;


      $scope.statusImage = {
        'status_image': 0
      };
      $scope.changeState = function () {
        //debugger;
        var test = $scope.singleDeviceStatus;
        $scope.key_irdata = "";
        $scope.noir = false;
        $scope.remoteTempOff = false;
        $scope.enableKey = [];
        $scope.remoreIrKey = {};
        $scope.device_b_one_id = $scope.localDeviceLatestStatus.device_b_one_id;

        $scope.remoteArrayData = JSON.parse($scope.remoteData);
        console.log("remote remote data: " + $scope.remoteData);
        irKeyLoop();

        function irKeyLoop() {
          //debugger;
          for (var i = 0; i < ($scope.remoteArrayData).length; i++) {
            $scope.enableKey.push($scope.remoteArrayData[i]);
            // $scope.key = ($scope.remoteArrayData[i].key_name).replace(/ /g,"_");
            // $scope.enableKey[$scope.key]=$scope.remoteArrayData[i].key_number;
            // $scope.irkey = ($scope.remoteArrayData[i].key_name).replace(/ /g,"_");
            // $scope.remoreIrKey[$scope.irkey]=$scope.remoteArrayData[i].key_irdata;
          };
        };
        // $scope.remoteStatusArray = ($scope.localDeviceLatestStatus.last_status_ac_remote).split(",")
        console.log("Filtered data: " + JSON.stringify($scope.enableKey));
      };
      $scope.sendIR = function (irData) {
        //debugger;
        $scope.loginAlertMessage = true;
        $scope.reqObject = {
          "remote_key_data": irData
        };
        $http.post($scope.localurlBase + '/event/sendEventForBots', {
          'user_id': $scope.localuserinfo.user_id,
          'app_device_token_id': 'LineWebRemote',
          'origin_id': 15,
          'hub_id': $scope.localuserinfo.hub_id,
          'device_b_one_id': $scope.localuserinfo.device_b_one_id,
          'wtoken_id': $scope.webToken,
          'source': 'webLine',
          'reqObject': $scope.reqObject,
        })
          .then(function (response) {
            //debugger;
            if (response.data.status == 1) {
              $scope.loginAlertMessage = false;
            } else {
              $scope.loginAlertMessage = false;
              $scope.notiError = true;
              $scope.notiErrorshow = false;
              $scope.notiErrorMessage = response.data.message;
            };
          });
      };
    }
    else if ($scope.localClickedDevice.category_id == '094fbdec-c3fc-4e64-993f-5815ae7099ae_old') {

      document.getElementById('ceilingbody').className = "my-body col-sm-12 col-xs-12 col-lg-12 col-xl-12 col-md-12 col-md-12 nopadding clearfix"
      $scope.loginAlertMessage = false;
      $scope.notifybutton = 1;
      $scope.layout = 0;
      $scope.brightValue = []
      $scope.colourValue = []
      $scope.remoteKeydata = {};
      $scope.brightColour = ["#808080", "#868686", "#8d8d8d", "#949494", "#999999", "#9f9f9f", "#a6a6a6", "#ababab", "#b3b3b3", "#b9b9b9", "#c0c0c0", "#c6c6c6", "#cccccc", "#c3c3c3", "#d9d9d9", "#dfdfdf", "#e6e6e6", "#ebebeb", "#f2f2f2", "#f8f8f8", "#ffffff", null];
      $scope.colorScale1 = ["#41bfed", "#67ccf1", "#8dd9f4", "#b3e5f8", "#d9f2fb", "#ffffff", "#fff6d2", "#ffe579", "#FFE579", "#ffdd4c", "#ffd41f", null];
      $scope.colorScale2 = ["#ffffff", "#fff6d2", "#ffe579", "#ffe579", "#ffdd4c", "#ffd41f", null];

      $scope.firstdeviceLatestStatusView();
      $scope.ceilinglight = {
        'device_id': $scope.localClickedDevice.category_id
      };
      console.log("data check value " + JSON.stringify($scope.ceilinglight));


      $scope.changeState = function () {
        $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
        var brightencolor = 21 / parseInt($scope.localDeviceLatestStatus.bright_max);
        $scope.brightValue.push($scope.brightColour[0])
        var i = 0.0;
        while (i < 20) {
          i = i + brightencolor;
          if (i > 20) {
            i = 20;
          }
          $scope.brightValue.push($scope.brightColour[Math.round(i)])

        }
        if ($scope.localDeviceLatestStatus.colour_scale == "1") {
          debugger;
          var colorValue = parseFloat(6 / parseInt($scope.localDeviceLatestStatus.colour_max));
          $scope.colourValue.push($scope.colorScale2[0])
          var j = 0.0;
          while (j < 6) {
            j = j + colorValue;
            if (j > 5) {
              $scope.colourValue.push($scope.colorScale2[Math.round(5)])
            }
            else {
              $scope.colourValue.push($scope.colorScale2[Math.round(j)])
            }

          }

        }
        else {
          debugger;
          var colorValue = parseFloat(11 / parseInt($scope.localDeviceLatestStatus.colour_max));
          $scope.colourValue.push($scope.colorScale1[0])
          var k = 0.0;
          while (k < 11) {
            k = k + colorValue;
            if (k > 10) {
              $scope.colourValue.push($scope.colorScale1[Math.round(10)])
            }
            else {
              $scope.colourValue.push($scope.colorScale1[Math.round(k)])
            }


          }

        }
        console.log("brinant check value" + JSON.stringify($scope.brightValue));
        console.log("colorcheck check value" + JSON.stringify($scope.colourValue))





        if ($scope.localDeviceLatestStatus.current_mode == "7") {
          if ($scope.localDeviceLatestStatus.colour_max == "1") {
            $scope.nightview = true;
            $scope.brigthview = false;

          }
          else {
            $scope.nightview = true;
            $scope.brigthview = true;
            document.getElementById("btdone").className = "light-option-width"
            document.getElementById("ctdone").className = "light-option-width"
            document.getElementById("btdtwo").className = "light-option-width"
            document.getElementById("ctdtwo").className = "light-option-width"
            document.getElementById("btdthree").className = "light-option-width"
            document.getElementById("ctdthree").className = "light-option-width"
          }
          $scope.current_colour = "NIGHT LIGHT"
          document.getElementById("nightcolordata").style.fontSize = "50px";
          $scope.current_bright = "1";
          $scope.arrowStatus = false;
          $scope.arrowStatus1 = false;
          document.getElementById('bringthcolor').style.background = '#808080';
          document.getElementById('wamercolor').style.background = '#eda112';

        }
        else if ($scope.localDeviceLatestStatus.current_mode == "5") {
          if ($scope.localDeviceLatestStatus.colour_max == "1") {
            $scope.nightview = false;
            $scope.brigthview = true;
          }
          else {
            $scope.nightview = true;
            $scope.brigthview = true;
          }

          document.getElementById("nightcolordata").style.fontSize = "100px";
          $scope.arrowStatus = false;
          $scope.arrowStatus1 = false;
          $scope.current_bright = 0;
          $scope.current_colour = 0;
          document.getElementById('mainbackdata').className = "light-table-body-widthlightcolor";
          document.getElementById('bringthcolor').style.background = '#808080';
          document.getElementById('wamercolor').style.background = '#808080';
        }
        else {
          document.getElementById("nightcolordata").style.fontSize = "100px";
          if ($scope.localDeviceLatestStatus.colour_max == "1") {
            $scope.nightview = false;
            $scope.brigthview = true;
          }
          else {
            $scope.nightview = true;
            $scope.brigthview = true;
            document.getElementById("btdone").className = "light-option-width"
            document.getElementById("ctdone").className = "light-option-width"
            document.getElementById("btdtwo").className = "light-option-width"
            document.getElementById("ctdtwo").className = "light-option-width"
            document.getElementById("btdthree").className = "light-option-width"
            document.getElementById("ctdthree").className = "light-option-width"
          }
          if ($scope.localDeviceLatestStatus.bright_max == "1") {
            document.getElementById('bringthcolor').style.background = '#ffffff';
            $scope.arrowStatus1 = false;
          }
          else {
            $scope.arrowStatus1 = true;
          }
          $scope.arrowStatus = true;
          $scope.current_bright = $scope.localDeviceLatestStatus.current_bright;
          $scope.current_colour = $scope.localDeviceLatestStatus.current_colour;
          document.getElementById('mainbackdata').className = "light-table-body-width";
          document.getElementById('bringthcolor').style.background = $scope.brightValue[parseInt($scope.localDeviceLatestStatus.current_bright)];

          document.getElementById('wamercolor').style.background = $scope.colourValue[parseInt($scope.localDeviceLatestStatus.current_colour)];
          if ($scope.localDeviceLatestStatus.current_bright == $scope.localDeviceLatestStatus.bright_max) {
            $scope.brightupstatus = true;
          }
          else {
            $scope.brightupstatus = false;
          }
          if ($scope.localDeviceLatestStatus.current_bright == "1") {
            $scope.brightdownstatus = true;
          } else {
            $scope.brightdownstatus = false;
          }
          if ($scope.localDeviceLatestStatus.current_colour == "1") {
            $scope.colourdownstatus = true;
          }
          else {
            $scope.colourdownstatus = false;

          }
          if ($scope.localDeviceLatestStatus.current_colour == $scope.localDeviceLatestStatus.colour_max) {
            $scope.colourupstatus = true;
          }
          else {
            $scope.colourupstatus = false;
          }
        }

        $scope.remoteData = JSON.parse(JSON.parse(localStorage.getItem('localDeviceLatestStatusRemote')));
        if ($scope.remoteData.length > 0) {
          $scope.enableKey = {};
          for (var i = 0; i < Object.keys($scope.remoteData).length; i++) {
            $scope.enableKey[$scope.remoteData[i].key_number] = $scope.remoteData[i].key_number;
          }


        }
        if ($scope.enableKey[1] != '1') {
          $scope.brightupstatus = true;
        }
        if ($scope.enableKey[2] != '2') {
          $scope.brightdownstatus = true;
        }
        if ($scope.enableKey[3] != '3') {
          $scope.colourdownstatus = true;
        }
        if ($scope.enableKey[4] != '4') {
          $scope.colourupstatus = true;
        }
        if ($scope.enableKey[5] != '5') {
          $scope.PowerOff = true;
        }
        if ($scope.enableKey[6] != '6') {
          $scope.AllLight = true;
        }
        if ($scope.enableKey[7] != '7') {
          $scope.NightLight = true;
        }


      }
      $scope.setmodeupdown = function (status) {

        $scope.reqobjectData = {};
        if (status == "1") {

          var bringt = parseInt($scope.localDeviceLatestStatus.current_bright) + 1
          $scope.reqobjectData.current_bright = bringt.toString()
        }
        if (status == "2") {

          var bringt = parseInt($scope.localDeviceLatestStatus.current_bright) - 1
          $scope.reqobjectData.current_bright = bringt.toString();
        }
        if (status == "3") {

          var bringt = parseInt($scope.localDeviceLatestStatus.current_colour) - 1
          $scope.reqobjectData.current_colour = bringt.toString();
        }
        if (status == "4") {

          var bringt = parseInt($scope.localDeviceLatestStatus.current_colour) + 1
          $scope.reqobjectData.current_colour = bringt.toString()

        }
        if (status == "5") {
          $scope.reqobjectData.current_mode = "5"
        }
        if (status == "6") {
          $scope.reqobjectData.current_mode = "6"
          $scope.reqobjectData.current_bright = $scope.localDeviceLatestStatus.bright_max;
          $scope.reqobjectData.current_colour = $scope.localDeviceLatestStatus.colour_max;
        }
        if (status == "7") {
          $scope.reqobjectData.current_mode = "7"
          $scope.reqobjectData.current_bright = $scope.localDeviceLatestStatus.bright_max;
          $scope.reqobjectData.current_colour = $scope.localDeviceLatestStatus.colour_max;
        }

        console.log("irdata check value :" + $scope.irdata);
        console.log("req Object  check value :" + JSON.stringify($scope.reqobjectData));
        $scope.remoteSendEvent($scope.irdata, $scope.reqobjectData)
        //debugger;

      }


      $scope.remoteSendEvent = function (irkey, reqData) {

        $scope.loginAlertMessage = true;
        //debugger;

        $scope.reqObject = {
          "remote_key_data": irkey
        };

        $http.post($scope.localurlBase + '/event/sendEventForBots', {
          'user_id': $scope.localuserinfo.user_id,
          'app_device_token_id': 'LineWebRemote',
          'origin_id': 15,
          'hub_id': $scope.localuserinfo.hub_id,
          'device_b_one_id': $scope.localuserinfo.device_b_one_id,
          'wtoken_id': $scope.webToken,
          'source': 'webLine',
          'reqObject': $scope.reqObject,
        })
          .then(function (response) {
            console.log("data test check in ac remote" + JSON.stringify(response));
            //debugger;

            if (response.data.status == 1) {
              $scope.remoteSetStatus(reqData);
              $scope.loginAlertMessage = false;
            } else {
              $scope.loginAlertMessage = false;
              $scope.notiError = true;
              $scope.notiErrorshow = false;
              $scope.notiErrorMessage = response.data.message;
            };
          });
      };
      $scope.remoteSetStatus = function (reqData) {
        $scope.reqObject = reqData;

        console.log("data request:" + JSON.stringify($scope.reqObject));
        //debugger;

        var json = {
          'user_id': $scope.localuserinfo.user_id,
          'app_device_token_id': 'LineWebRemote',
          'origin_id': 15,
          'device_b_one_id': $scope.localuserinfo.device_b_one_id,
          'hub_id': $scope.localuserinfo.hub_id,
          'reqObject': $scope.reqObject
        };
        console.log('data for set status value :' + JSON.stringify(json))
        $http.post($scope.localurlBase + '/event/SetStatusForBots', json)
          .then(function (response) {
            //debugger;
            $scope.deviceLatestStatusView();

          });
      };



      //debugger;

    }
    else if ($scope.localClickedDevice.category_id == '094fbdec-c3fc-4e64-993f-5815ae7099ae') {

      $scope.loginAlertMessage = false;
      $scope.notifybutton = 1;
      $scope.layout = 0;
      $scope.brightValue = []
      $scope.colourValue = []
      $scope.remoteKeydata = {};
      $scope.brightColour = ["#808080", "#868686", "#8d8d8d", "#949494", "#999999", "#9f9f9f", "#a6a6a6", "#ababab", "#b3b3b3", "#b9b9b9", "#c0c0c0", "#c6c6c6", "#cccccc", "#c3c3c3", "#d9d9d9", "#dfdfdf", "#e6e6e6", "#ebebeb", "#f2f2f2", "#f8f8f8", "#ffffff", null];
      $scope.colorScale1 = ["#41bfed", "#67ccf1", "#8dd9f4", "#b3e5f8", "#d9f2fb", "#ffffff", "#fff6d2", "#ffe579", "#FFE579", "#ffdd4c", "#ffd41f", null];
      $scope.colorScale2 = ["#ffffff", "#fff6d2", "#ffe579", "#ffe579", "#ffdd4c", "#ffd41f", null];

      $scope.firstdeviceLatestStatusView();
      $scope.ceilinglightnew = {
        'device_id': $scope.localClickedDevice.category_id
      };
      console.log("data check value " + JSON.stringify($scope.ceilinglight));


      $scope.changeState = function () {
        $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
        var brightencolor = 21 / parseInt($scope.localDeviceLatestStatus.bright_max);
        $scope.brightValue.push($scope.brightColour[0])
        var i = 0.0;
        while (i < 20) {
          i = i + brightencolor;
          if (i > 20) {
            i = 20;
          }
          $scope.brightValue.push($scope.brightColour[Math.round(i)])

        }
        if ($scope.localDeviceLatestStatus.colour_scale == "1") {
          debugger;
          var colorValue = parseFloat(6 / parseInt($scope.localDeviceLatestStatus.colour_max));
          $scope.colourValue.push($scope.colorScale2[0])
          var j = 0.0;
          while (j < 6) {
            j = j + colorValue;
            if (j > 5) {
              $scope.colourValue.push($scope.colorScale2[Math.round(5)])
            }
            else {
              $scope.colourValue.push($scope.colorScale2[Math.round(j)])
            }

          }

        }
        else {
          debugger;
          var colorValue = parseFloat(11 / parseInt($scope.localDeviceLatestStatus.colour_max));
          $scope.colourValue.push($scope.colorScale1[0])
          var k = 0.0;
          while (k < 11) {
            k = k + colorValue;
            if (k > 10) {
              $scope.colourValue.push($scope.colorScale1[Math.round(10)])
            }
            else {
              $scope.colourValue.push($scope.colorScale1[Math.round(k)])
            }


          }

        }
        console.log("brinant check value" + JSON.stringify($scope.brightValue));
        console.log("colorcheck check value" + JSON.stringify($scope.colourValue))





        if ($scope.localDeviceLatestStatus.current_mode == "7") {
          if ($scope.localDeviceLatestStatus.colour_max == "1") {
            $scope.nightview = true;
            $scope.brigthview = false;

          }
          else {
            $scope.nightview = true;
            $scope.brigthview = true;

          }
          $scope.current_colour = "NIGHT LIGHT"

          $scope.current_bright = "1";
          $scope.arrowStatus = false;
          $scope.arrowStatus1 = false;

        }
        else if ($scope.localDeviceLatestStatus.current_mode == "5") {
          if ($scope.localDeviceLatestStatus.colour_max == "1") {
            $scope.nightview = false;
            $scope.brigthview = true;
          }
          else {
            $scope.nightview = true;
            $scope.brigthview = true;
          }

          $scope.arrowStatus = false;
          $scope.arrowStatus1 = false;
          $scope.current_bright = 0;
          $scope.current_colour = 0;

        }
        else {

          if ($scope.localDeviceLatestStatus.colour_max == "1") {
            $scope.nightview = false;
            $scope.brigthview = true;
          }
          else {
            $scope.nightview = true;
            $scope.brigthview = true;
          }
          if ($scope.localDeviceLatestStatus.bright_max == "1") {
            document.getElementById('bringthcolor').style.background = '#ffffff';
            $scope.arrowStatus1 = false;
          }
          else {
            $scope.arrowStatus1 = true;
          }
          $scope.arrowStatus = true;
          $scope.current_bright = $scope.localDeviceLatestStatus.current_bright;
          $scope.current_colour = $scope.localDeviceLatestStatus.current_colour;
          if ($scope.localDeviceLatestStatus.current_bright == $scope.localDeviceLatestStatus.bright_max) {
            $scope.brightupstatus = true;
          }
          else {
            $scope.brightupstatus = false;
          }
          if ($scope.localDeviceLatestStatus.current_bright == "1") {
            $scope.brightdownstatus = true;
          } else {
            $scope.brightdownstatus = false;
          }
          if ($scope.localDeviceLatestStatus.current_colour == "1") {
            $scope.colourdownstatus = true;
          }
          else {
            $scope.colourdownstatus = false;

          }
          if ($scope.localDeviceLatestStatus.current_colour == $scope.localDeviceLatestStatus.colour_max) {
            $scope.colourupstatus = true;
          }
          else {
            $scope.colourupstatus = false;
          }
        }

        $scope.remoteData = JSON.parse(JSON.parse(localStorage.getItem('localDeviceLatestStatusRemote')));
        if ($scope.remoteData.length > 0) {
          $scope.enableKey = {};
          for (var i = 0; i < Object.keys($scope.remoteData).length; i++) {
            $scope.enableKey[$scope.remoteData[i].key_number] = $scope.remoteData[i].key_number;
          }


        }
        if ($scope.enableKey[1] != '1') {
          $scope.brightupstatus = true;
        }
        if ($scope.enableKey[2] != '2') {
          $scope.brightdownstatus = true;
        }
        if ($scope.enableKey[3] != '3') {
          $scope.colourdownstatus = true;
        }
        if ($scope.enableKey[4] != '4') {
          $scope.colourupstatus = true;
        }
        if ($scope.enableKey[5] != '5') {
          $scope.PowerOff = true;
        }
        if ($scope.enableKey[6] != '6') {
          $scope.AllLight = true;
        }
        if ($scope.enableKey[7] != '7') {
          $scope.NightLight = true;
        }


      }
      $scope.setmodeupdown = function (status) {
        $scope.remoteData = JSON.parse(JSON.parse(localStorage.getItem('localDeviceLatestStatusRemote')));
        console.log("irdata check value is:" + JSON.stringify($scope.remoteData));
        for (var i = 0; i < Object.keys($scope.remoteData).length; i++) {
          if ($scope.remoteData[i].key_number == status) {
            $scope.irdata = $scope.remoteData[i].key_irdata;
            break;
          }

        }
        $scope.reqobjectData = {};
        if (status == "1") {

          var bringt = parseInt($scope.localDeviceLatestStatus.current_bright) + 1
          $scope.reqobjectData.current_bright = bringt.toString()
        }
        if (status == "2") {

          var bringt = parseInt($scope.localDeviceLatestStatus.current_bright) - 1
          $scope.reqobjectData.current_bright = bringt.toString();
        }
        if (status == "3") {

          var bringt = parseInt($scope.localDeviceLatestStatus.current_colour) - 1
          $scope.reqobjectData.current_colour = bringt.toString();
        }
        if (status == "4") {

          var bringt = parseInt($scope.localDeviceLatestStatus.current_colour) + 1
          $scope.reqobjectData.current_colour = bringt.toString()

        }
        if (status == "5") {
          $scope.reqobjectData.current_mode = "5"
        }
        if (status == "6") {
          $scope.reqobjectData.current_mode = "6"
          $scope.reqobjectData.current_bright = $scope.localDeviceLatestStatus.bright_max;
          $scope.reqobjectData.current_colour = $scope.localDeviceLatestStatus.colour_max;
        }
        if (status == "7") {
          $scope.reqobjectData.current_mode = "7"
          $scope.reqobjectData.current_bright = $scope.localDeviceLatestStatus.bright_max;
          $scope.reqobjectData.current_colour = $scope.localDeviceLatestStatus.colour_max;
        }

        console.log("req Object  check value :" + JSON.stringify($scope.reqobjectData));
        console.log("IR Object  check value :" + JSON.stringify($scope.irdata));
        if ($scope.irdata != undefined && ($scope.irdata).length > 10) {
          $scope.remoteSendEvent($scope.irdata, $scope.reqobjectData)
        }
        //debugger;
      }


      $scope.remoteSendEvent = function (irkey, reqData) {

        $scope.loginAlertMessage = true;
        //debugger;

        $scope.reqObject = {
          "remote_key_data": irkey
        };
        if ($scope.localDeviceLatestStatus.extender_id != undefined && ($scope.localDeviceLatestStatus.extender_id).length > 6) {
          $scope.reqObject.extender_id = $scope.localDeviceLatestStatus.extender_id;
        }

        $http.post($scope.localurlBase + '/event/sendEventForBots', {
          'user_id': $scope.localuserinfo.user_id,
          'app_device_token_id': 'LineWebRemote',
          'origin_id': 15,
          'hub_id': $scope.localuserinfo.hub_id,
          'device_b_one_id': $scope.localuserinfo.device_b_one_id,
          'wtoken_id': $scope.webToken,
          'source': 'webLine',
          'reqObject': $scope.reqObject,
        })
          .then(function (response) {
            console.log("data test check in ac remote" + JSON.stringify(response));
            //debugger;

            if (response.data.status == 1) {
              $scope.remoteSetStatus(reqData);
              $scope.loginAlertMessage = false;
            } else {
              $scope.loginAlertMessage = false;
              $scope.notiError = true;
              $scope.notiErrorshow = false;
              $scope.notiErrorMessage = response.data.message;
            };
          });
      };
      $scope.remoteSetStatus = function (reqData) {
        $scope.reqObject = reqData;

        console.log("data request:" + JSON.stringify($scope.reqObject));
        //debugger;

        var json = {
          'user_id': $scope.localuserinfo.user_id,
          'app_device_token_id': 'LineWebRemote',
          'origin_id': 15,
          'device_b_one_id': $scope.localuserinfo.device_b_one_id,
          'hub_id': $scope.localuserinfo.hub_id,
          'reqObject': $scope.reqObject
        };
        console.log('data for set status value :' + JSON.stringify(json))
        $http.post($scope.localurlBase + '/event/SetStatusForBots', json)
          .then(function (response) {
            //debugger;
            $scope.deviceLatestStatusView();

          });
      };



      //debugger;

    }
    else if($scope.localClickedDevice.category_id == '6d7e8989-a939-4693-961b-772237ac1332'){
      $scope.loginAlertMessage = false;
      $scope.notifybutton = 1;
      $scope.layout = 0;
      $scope.ReqObjectTuya={};
      $scope.MotionSwitch=false;
      $scope.MotionPic="public/images/room.jpg";
      $scope.firstdeviceLatestStatusView();
      $scope.tuyacamera = {
        'device_id': $scope.localClickedDevice.category_id
      };
      
      $scope.changeState = function () {
        $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
        var Obj={hub_id:$scope.localuserinfo.hub_id,device_b_one_id:$scope.localuserinfo.device_b_one_id,tuya_device_id:$scope.localDeviceLatestStatus.device_id_tuya}
        $scope.getTuyadeviceStatus(Obj)
      }
      $scope.MotionStatusChange=function(motion_status){
        console.log("Motionstatus:",motion_status);
        var motion_status1=true
        if(motion_status){
          motion_status1=false;
        }
        var Obj={hub_id:$scope.localuserinfo.hub_id,device_b_one_id:$scope.localuserinfo.device_b_one_id,tuya_device_id:$scope.localDeviceLatestStatus.device_id_tuya,commands:[{code:"motion_switch",value:""+motion_status1}]}
        $scope.gettuyaControl(Obj);
      }
    }
    else if($scope.localClickedDevice.category_id == '38c8d7f9-233d-44b0-a249-e088839d7599'){
      $scope.loginAlertMessage = false;
      $scope.ControlTuya=false;
      $scope.notifybutton = 1;
      $scope.layout = 0;
      $scope.ReqObjectTuya={};
      $scope.PowerOff=false;
      $scope.colourbut=false;
      $scope.MotionSwitch=false;
      $scope.BrightnessValue="0";
      $scope.SaturationValue="0";
      $scope.MotionPic="public/images/room.jpg";
      $scope.firstdeviceLatestStatusView();
      $scope.tuyalight = {
        'device_id': $scope.localClickedDevice.category_id
      };
      console.log("tuya light device id",$scope.tuyalight)
      var colorrange = document.getElementById("sliderRange");
      var BrightnessrangeSlider = document.getElementById("brightness-range-line");
      var BrightnessrangeBullet = document.getElementById("brightness-bullet");
      BrightnessrangeBullet.style.left = "12%";
      var SaturationrangeSlider = document.getElementById("saturation-range-line");
      var SaturationrangeBullet = document.getElementById("saturation-bullet");
      SaturationrangeBullet.style.left = "12%";
      
      BrightnessrangeSlider.addEventListener("change", BrighterSliderValue, false);
      SaturationrangeSlider.addEventListener("change", SaturationSliderValue, false);
      
      function BrighterSliderValue() {
        var commands=[]
        $scope.BrightnessValue=BrightnessrangeSlider.value
        BrightnessrangeBullet.innerHTML = ($scope.BrightnessValue) + "%";
        BrightnessrangeBullet.style.left = (12+((60/100)*$scope.BrightnessValue)) + "%";
        if(window.screen.availWidth > 600){
          BrightnessrangeBullet.style.left = (12+((70/100)*$scope.BrightnessValue)) + "%";
        }
        if($scope.colourbut){
          var data=$scope.DataBright;
          var value=$scope.BrightnessValue
          data.v=""+Math.round((255/100)*value);
          console.log("v value",data.v)
          commands.push({code:"colour_data",value:data});
        }
        else{
          var value=$scope.BrightnessValue;
          var data=""+Math.round((255/100)*value);
          commands.push({code:"bright_value",value:data});
        }
        if(commands.length>0){
          console.log("hub_id",$scope.localuserinfo.hub_id)
          console.log("bone id",$scope.localuserinfo.device_b_one_id)
         
          console.log("commands",commands)
          var Obj={hub_id:$scope.localuserinfo.hub_id,device_b_one_id:$scope.localuserinfo.device_b_one_id,tuya_device_id:$scope.localDeviceLatestStatus.device_id_tuya,commands:commands}
          $scope.gettuyaControl(Obj);
        }
       
      }
      function SaturationSliderValue() {
        var commands=[]
        $scope.SaturationValue=SaturationrangeSlider.value
        SaturationrangeBullet.innerHTML = ($scope.SaturationValue) + "%";
        SaturationrangeBullet.style.left = (12+((60/100)*$scope.SaturationValue)) + "%";
        if(window.screen.availWidth > 600){
          SaturationrangeBullet.style.left = (12+((70/100)*$scope.SaturationValue)) + "%";
        }
        var data=$scope.DataBright;
        var value=parseInt($scope.SaturationValue);
           
            data.s=""+Math.round((255/100)*value);
            commands.push({code:"colour_data",value:data});
        if(commands.length>0){
          console.log("hub_id",$scope.localuserinfo.hub_id)
          console.log("bone id",$scope.localuserinfo.device_b_one_id)
         
          console.log("commands",commands)
          var Obj={hub_id:$scope.localuserinfo.hub_id,device_b_one_id:$scope.localuserinfo.device_b_one_id,tuya_device_id:$scope.localDeviceLatestStatus.device_id_tuya,commands:commands}
          $scope.gettuyaControl(Obj);
        }
       
      }


      $scope.changeState = function () {
        $scope.ControlTuya=false
        $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
        var Obj={hub_id:$scope.localuserinfo.hub_id,device_b_one_id:$scope.localuserinfo.device_b_one_id,tuya_device_id:$scope.localDeviceLatestStatus.device_id_tuya}
        console.log("tuya object",Obj)
      
        $scope.getTuyadeviceStatus(Obj);
        

        $scope.localDeviceLatestStatusTuya = JSON.parse(localStorage.getItem('localDeviceLatestStatusTuya'));

        var PowerState=_.where($scope.localDeviceLatestStatusTuya.result,{code:"switch_led"})
        var Work_Mode=_.where($scope.localDeviceLatestStatusTuya.result,{code:"work_mode"})
        var Color_Mode=_.where($scope.localDeviceLatestStatusTuya.result,{code:"colour_data"})
        var White_Mode=_.where($scope.localDeviceLatestStatusTuya.result,{code:"bright_value"})
        if(PowerState[0].value=="true"){
         
          $scope.PowerOff=false;
          BrightnessrangeSlider.disabled = false;
          
          if(Work_Mode[0].value=="colour")
          {
            document.getElementById("colourbut").className="tuya_text_color_blue"
            document.getElementById("whithbut").className="tuya_text_color_gray"
            $scope.colourbut=true;
            SaturationrangeSlider.disabled=false;
          }
          if(Work_Mode[0].value=="white")
          {
            document.getElementById("whithbut").className="tuya_text_color_blue"
            document.getElementById("colourbut").className="tuya_text_color_gray"
            $scope.colourbut=false;
            SaturationrangeSlider.disabled=true;
            //$('#saturation-range-line').slider('disable');
          }
        }
        if(PowerState[0].value=="false"){
          $scope.PowerOff=true;
          document.getElementById("whithbut").className="tuya_text_color_gray"
          document.getElementById("colourbut").className="tuya_text_color_gray"
          $scope.colourbut=false;
          SaturationrangeSlider.disabled=true;
          BrightnessrangeSlider.disabled = true;
        }
        $scope.DataBright=JSON.parse(Color_Mode[0].value)
        if(Work_Mode[0].value=="colour")
        {
          $scope.BrightnessValue=""+Math.round((parseInt($scope.DataBright.v)/255)*100);
          BrightnessrangeSlider.value=$scope.BrightnessValue;
          $scope.invert=parseInt($scope.DataBright.h);
          colorrange.value=$scope.invert;
          BrightnessrangeBullet.innerHTML = (parseInt($scope.BrightnessValue)) + "%";
          BrightnessrangeBullet.style.left = (12+((60/100)*parseInt($scope.BrightnessValue))) + "%";
        if(window.screen.availWidth > 600){
          BrightnessrangeBullet.style.left = (12+((70/100)*parseInt($scope.BrightnessValue))) + "%";
        }
        }
        if(Work_Mode[0].value=="white")
        {
          $scope.BrightnessValue=""+Math.round((parseInt(White_Mode[0].value)/255)*100);
          BrightnessrangeSlider.value=$scope.BrightnessValue;
          BrightnessrangeBullet.innerHTML = (parseInt($scope.BrightnessValue)) + "%";
          BrightnessrangeBullet.style.left = (12+((60/100)*parseInt($scope.BrightnessValue))) + "%";
        if(window.screen.availWidth > 600){
          BrightnessrangeBullet.style.left = (12+((70/100)*parseInt($scope.BrightnessValue))) + "%";
        }
        }
        $scope.SaturationValue=""+Math.round((parseInt($scope.DataBright.s)/255)*100);
        SaturationrangeSlider.value=$scope.SaturationValue;
        SaturationrangeBullet.innerHTML = ($scope.SaturationValue) + "%";
        SaturationrangeBullet.style.left = (12+((60/100)*$scope.SaturationValue)) + "%";
        if(window.screen.availWidth > 600){
          SaturationrangeBullet.style.left = (12+((70/100)*$scope.SaturationValue)) + "%";
        }
        


      }
      $scope.LightStatusChange=function(status){
        console.log("status:",status);
        var commands=[]
        $scope.loginAlertMessage = true;
        if(status=="1"){
        commands.push({code:"switch_led",value:''+$scope.PowerOff});
        }
        if(status=="2"){
         
          if($scope.colourbut){
            console.log("status 2")
            commands.push({code:"work_mode",value:'white'});
          }
        }
        if(status=="3"){
            if(!$scope.colourbut){
              commands.push({code:"work_mode",value:'colour'});
            }
        }
        if(status=="4"){
            if($scope.colourbut){
              var data=$scope.DataBright;
              var value=parseInt($scope.BrightnessValue)+5;
              if(value > 100){
                value = 100;
              }
              data.v=""+Math.round((255/100)*value);
              console.log("v value",data.v)
              commands.push({code:"colour_data",value:data});
            }
            else{
              var value=parseInt($scope.BrightnessValue)+5;
              if(value > 100){
                value = 100;
              }
              var data=""+Math.round((255/100)*value);
              commands.push({code:"bright_value",value:data});
            }
        }
        if(status=="5"){
          if($scope.colourbut){
            var data=$scope.DataBright;
            var value=parseInt($scope.BrightnessValue)-5;
            if(value < 0){
              value = 0;
            }
            data.v=""+Math.round((255/100)*value);
            commands.push({code:"colour_data",value:data});
          }
          else{
            var value=parseInt($scope.BrightnessValue)-5;
            if(value < 0){
              value = 0;
            }
            var data=""+Math.round((255/100)*value);
            commands.push({code:"bright_value",value:data});
          }
        }
        if(status=="6"){
            var data=$scope.DataBright;
            var value=parseInt($scope.SaturationValue)+5;
            if(value > 100){
              value = 100;
            }
            data.s=""+Math.round((255/100)*value);
            commands.push({code:"colour_data",value:data});
          
      }
      if(status=="7"){
          var data=$scope.DataBright;
          var value=parseInt($scope.SaturationValue)-5;
          if(value < 0){
            value = 0;
          }
          data.s=""+Math.round((255/100)*value);
          commands.push({code:"colour_data",value:data});
        
      }
      if(commands.length>0){
        console.log("hub_id",$scope.localuserinfo.hub_id)
        console.log("bone id",$scope.localuserinfo.device_b_one_id)
       
        console.log("commands",commands)
        var Obj={hub_id:$scope.localuserinfo.hub_id,device_b_one_id:$scope.localuserinfo.device_b_one_id,tuya_device_id:$scope.localDeviceLatestStatus.device_id_tuya,commands:commands}
        $scope.gettuyaControl(Obj);
      }

        
      }
      $scope.invert = 0
      $scope.count_new = $scope.BrightnessValue;
   
      colorrange.addEventListener("change", function () {
        console.log("value:" + colorrange.value);
        var commands=[];
        $scope.invert=colorrange.value
        var data=$scope.DataBright;
        data.h=""+$scope.invert;
        commands.push({code:"colour_data",value:data});
        if(commands.length>0){
          var Obj={hub_id:$scope.localuserinfo.hub_id,device_b_one_id:$scope.localuserinfo.device_b_one_id,tuya_device_id:$scope.localDeviceLatestStatus.device_id_tuya,commands:commands}
          $scope.gettuyaControl(Obj);
        }
      })

     

     
    


    }
    else {
      $scope.loginAlertMessage = false;
      $scope.notiError = true;
      $scope.notiErrorshow = false;
      $scope.notiErrorMessage = "無効なリクエスト";
    }

    $scope.show_graph = false;


  };
  //Get All Device List End



  //Notify me

  ///Removed getLatsetStatus Function, Add it after this

  $scope.activeSecurity = function (key1, keyvalue1, key2, keyvalue2, bid) {
    //////debugger;
    //$scope.loginAlertMessage=true;
    $scope.loginAlertMessage = true;
    $scope.reqObject = {};
    $scope.reqObject[key1] = keyvalue1;
    $scope.reqObject[key2] = keyvalue2;
    $scope.device_b_one_id = bid;

    $scope.localAllHubs = JSON.parse(localStorage.getItem('localAllHubs'));
    $scope.hubId = $scope.localAllHubs.hub_id;
    //////console.log("This is hub ID " + JSON.stringify($scope.hubId));
    $http.post($scope.localurlBase + '/event/sendEvent', {
      'user_id': $scope.localuserinfo.user_id,
      'sessionId': $scope.localuserresponse.sessionId,
      'app_device_token_id': 'LineWebRemote',
      'origin_id': 15,
      'hub_id': $scope.hubId,
      'device_b_one_id': $scope.device_b_one_id,
      'reqObject': $scope.reqObject
    })
      .then(function (response) {
        ////////debugger;
        $scope.deviceSetSecurity = response.data;
        $scope.deviceSetSecurityStatus = response.data.data;
        ////console.log("This is New device security status " + JSON.stringify($scope.deviceSetSecurity));
        localStorage.setItem("localDeviceSetStatus", JSON.stringify($scope.deviceSetSecurity));
        $scope.localDeviceSetStatus = JSON.parse(localStorage.getItem('localDeviceSetStatus'));
        //$scope.loginAlertMessage = false;
        //$timeout(function () { $scope.loginAlertMessage = false; }, 5000);
        $timeout(function () {
          $scope.loginAlertMessage = false;
        }, 2000);

        $scope.checkedStatus();


      })


  };

  $scope.getTuyadeviceStatus= function(ObjRequest){
    var ReqObject={
      "hub_id":ObjRequest.hub_id,
       "details" :     {
           "op" : "get_device_status",
           "op_param" :{
                "device_id" : ObjRequest.tuya_device_id
           },
           "req_id" : ObjRequest.hub_id+"_"+ObjRequest.device_b_one_id
       },
     
       "tp_id" :"1001",
       "tp_name":"tuya"
       }
       //console.log("Req Object:"+JSON.stringify(ReqObject));
    $http.post($scope.localurlBase + '/thirdparty/v1/control/int/exec',ReqObject )
      .then(function (response) {
        if(response.data.status=="1"){
          $scope.loginAlertMessage = false;
          if($scope.localClickedDevice.category_id=="6d7e8989-a939-4693-961b-772237ac1332")
          { 
            var ResponseData=response.data.data.result;
            var MotionSwitchObj=_.where(ResponseData,{"code":"motion_switch"})
            if(MotionSwitchObj.length>0){
              if(MotionSwitchObj[0].value=="true"){
                $scope.MotionSwitch=true;
                var MotionPicObj=_.where(ResponseData,{"code":"movement_detect_pic"})
            if(MotionPicObj.length>0){
              var ImaPic=JSON.parse(atob(MotionPicObj[0].value))
              //{"v":"1.0","bucket":"ty-us-storage30","files":[["/eb47f0-6750395-pp01ef536280e348e21d/detect/1576499981.jpg",""]]}
              console.log("Pic value"+JSON.stringify(ImaPic));

              var file_path=ImaPic.files[0]
              var Command={
                "bucket":ImaPic.bucket,
                "file_path":file_path[0]
               }
               ObjRequest.commands=Command;
               $scope.gettuyaCamPic(ObjRequest)

            }
              }
              if(MotionSwitchObj[0].value=="false"){
                $scope.MotionSwitch=false;
              }
            }          
            
          }
          if($scope.localClickedDevice.category_id=="38c8d7f9-233d-44b0-a249-e088839d7599"){
            localStorage.setItem('localDeviceLatestStatusTuya', JSON.stringify(response.data.data));
           
            if($scope.ControlTuya){
              $scope.changeState()
            }
          }

        }
      })
  }
  $scope.gettuyaCamPic= function(ObjRequest){
    var ReqObject={
      "hub_id":ObjRequest.hub_id,
       "details" :     {
           "op" : "get_motion_picture",
           "op_param" :{
                "device_id" : ObjRequest.tuya_device_id,
                "commands":ObjRequest.commands
           },
           "req_id" : ObjRequest.hub_id+"_"+ObjRequest.device_b_one_id
       },
     
       "tp_id" :"1001",
       "tp_name":"tuya"
       }

    $http.post('https://b1f0b070.ngrok.io/thirdparty/v1/control/int/exec',ReqObject)
      .then(function (response) {
        if(response.data.status=="1"){
          $scope.loginAlertMessage = false;
          //console.log("data",response.data)
          $scope.MotionPic=response.data.data.result;
        }
      })
  }
  $scope.gettuyaControl = function (ObjRequest){
    $scope.ControlTuya=true;
    var ReqObject={
      "hub_id":ObjRequest.hub_id,
       "details" :     {
           "op" : "control",
           "op_param" :{
                "device_id" : ObjRequest.tuya_device_id,
                "commands":ObjRequest.commands
           },
           "req_id" : ObjRequest.hub_id+"_"+ObjRequest.device_b_one_id
       },
     
       "tp_id" :"1001",
       "tp_name":"tuya"
       }
    //console.log("ReqObject:"+JSON.stringify(ReqObject));
    $http.post($scope.localurlBase + '/thirdparty/v1/control/int/exec',ReqObject)
      .then(function (response) {
        if(response.data.status=="1"){
          delete ObjRequest.commands;
          setTimeout(function(){
            $scope.getTuyadeviceStatus(ObjRequest);
          },3000)
          
        }
      })
  }

  $scope.deviceLatestStatusView = function () {
    //debugger;
    //$scope.loginAlertMessage=true;
    $http.post($scope.localurlBase + '/event/getLatestStatusIRWeb', {
      'user_id': $scope.localuserinfo.user_id,
      'app_device_token_id': 'LineWebRemote',
      'origin_id': 15,
      'hub_id': $scope.localuserinfo.hub_id,
      'reqObject': $scope.reqObject,
      'device_b_one_id': $scope.localuserinfo.device_b_one_id
    })
      .then(function (response) {
        // //debugger;
        $scope.singleDeviceStatus = response.data.data;
        $scope.singleDeviceStatusMessage = response.data;
        if ($scope.singleDeviceStatusMessage.status == 1) {
          $scope.loginAlertMessage = false;
        } else {
          // $scope.loginAlertMessage = false;
        };
        ////console.log("This is device latest status : " + JSON.stringify($scope.singleDeviceStatusMessage));
        $scope.localallUserActivities = JSON.parse(localStorage.getItem('localallUserActivities'));
        localStorage.setItem('localDeviceLatestStatus', JSON.stringify($scope.singleDeviceStatus));
        $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
        //$scope.getDeviceLatestStatus();
        $scope.changeState();
        //$scope.loginAlertMessage=false; 

      });
  }

  $scope.deviceLatestStatusViewAIrepate = function () {
    //debugger;
    //$scope.loginAlertMessage=true;
    $http.post($scope.localurlBase + '/event/getLatestStatusIRWeb', {
      'user_id': $scope.localuserinfo.user_id,
      'app_device_token_id': 'LineWebRemote',
      'origin_id': 15,
      'hub_id': $scope.localuserinfo.hub_id,
      'reqObject': $scope.reqObject,
      'device_b_one_id': $scope.localuserinfo.device_b_one_id
    })
      .then(function (response) {
        // //debugger;
        $scope.singleDeviceStatus = response.data.data;
        $scope.singleDeviceStatusMessage = response.data;
        if ($scope.singleDeviceStatusMessage.status == 1) {
          $scope.loginAlertMessage = false;
        } else {
          // $scope.loginAlertMessage = false;
        };
        ////console.log("This is device latest status : " + JSON.stringify($scope.singleDeviceStatusMessage));
        $scope.localallUserActivities = JSON.parse(localStorage.getItem('localallUserActivities'));
        localStorage.setItem('localDeviceLatestStatus', JSON.stringify($scope.singleDeviceStatus));
        $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
        //$scope.getDeviceLatestStatus();
        $scope.changeState();
        //$scope.loginAlertMessage=false; 

      });
  }


  $scope.AistatusAddindata = function () {
    var dataval = {};
    var statusCheck = "0";

    if ($scope.AiStatusCheck == "2") {
      $scope.localDeviceAIStatusAll = JSON.parse(localStorage.getItem('localDeviceAIStatusAll'));
      if ($scope.localDeviceAIStatusAll != undefined && $scope.localDeviceAIStatusAll != null && $scope.localDeviceAIStatusAll != "") {
        $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));


        dataval = $scope.localDeviceAIStatusAll[0];
        delete dataval.id;
        delete dataval.is_active;
        delete dataval.created_date;
        delete dataval.modified_date;
        dataval.hub_id = $scope.localuserinfo.hub_id;
        dataval.device_id = $scope.localDeviceLatestStatus.device_id;
        dataval.device_b_one_id = $scope.localDeviceLatestStatus.device_b_one_id;
        dataval.ai_status = "1";
        statusCheck = "2"

      }
      else {
        $scope.showAlert("Please set AI setting in Mobile Application.")

      }

    }
    else if ($scope.AiStatusCheck == "1") {
      $scope.localDeviceAIStatus = JSON.parse(localStorage.getItem('localDeviceAIStatus'));
      dataval = $scope.localDeviceAIStatus
      delete dataval.id;
      delete dataval.is_active;
      delete dataval.created_date;
      delete dataval.modified_date;
      dataval.ai_status = "0";
      statusCheck = "1"
    }
    else if ($scope.AiStatusCheck == "0") {
      $scope.localDeviceAIStatus = JSON.parse(localStorage.getItem('localDeviceAIStatus'));
      dataval = $scope.localDeviceAIStatus
      delete dataval.id;
      delete dataval.is_active;
      delete dataval.create_date;
      delete dataval.modified_date;
      dataval.ai_status = "1";
      statusCheck = "1"
    }
    else {
      $scope.showAlert("Please set AI setting on Mobile Application.")
    }
    console.log("new data value is check" + JSON.stringify(dataval));
    console.log("new data value is check" + JSON.stringify($scope.localDeviceAIStatusAll));
    debugger;
    var pushDataArray = []
    if (statusCheck == "2") {
      pushDataArray = JSON.parse(localStorage.getItem('localDeviceAIStatusAll'));
      for (var i = 0; i < Object.keys(pushDataArray).length; i++) {
        delete pushDataArray[i].id;
        delete pushDataArray[i].is_active;
        delete pushDataArray[i].create_date;
        delete pushDataArray[i].modified_date;
      }
      pushDataArray.push(dataval);
      updatedeviceAIStatus(pushDataArray)
    }
    if (statusCheck == "1") {
      $scope.localDeviceLatestStatus = JSON.parse(localStorage.getItem('localDeviceLatestStatus'));
      pushDataArray = JSON.parse(localStorage.getItem('localDeviceAIStatusAll'));
      for (var i = 0; i < Object.keys(pushDataArray).length; i++) {
        delete pushDataArray[i].id;
        delete pushDataArray[i].is_active;
        delete pushDataArray[i].create_date;
        delete pushDataArray[i].modified_date;
        if (pushDataArray[i].device_b_one_id == $scope.localDeviceLatestStatus.device_b_one_id && pushDataArray[i].hub_id == $scope.localDeviceLatestStatus.hub_id) {
          pushDataArray[i] = dataval;
        }
      }
      updatedeviceAIStatus(pushDataArray)
    }
    console.log("new data value is check" + JSON.stringify(pushDataArray));

    debugger;
  }



  function GetdeviceAIStatus(device_b_one_id, hub_id) {

    $http.post($scope.localurlBase + '/ai/getAIConfigLine', {
      'user_id': $scope.localuserinfo.user_id, 'token': $scope.webToken
    })
      .then(function (response) {

        $responddatastatus = response.data;
        if ($responddatastatus.status == 1) {
          if (Object.keys($responddatastatus.data).length > 0) {
            var dataLength = Object.keys($responddatastatus.data).length;
            for (var i = 0; i < dataLength; i++) {
              if (device_b_one_id == $responddatastatus.data[i].device_b_one_id && hub_id == $responddatastatus.data[i].hub_id) {

                localStorage.setItem("localDeviceAIStatus", JSON.stringify($responddatastatus.data[i]));
                $scope.localDeviceAIStatus = JSON.parse(localStorage.getItem('localDeviceAIStatus'));


                if ($scope.localDeviceAIStatus.ai_status == "1") {

                  $scope.aiimgarrowData = false;
                  $scope.AiStatusCheck = "1";
                  document.getElementById('aiimage').setAttribute('src', "Public/images/aion.png");
                  $scope.changeState();
                  //document.getElementById('ai_curical').className="ls-mini-ai-circle"
                }
                else {
                  $scope.aiimgarrowData = true;
                  $scope.AiStatusCheck = "0";
                  document.getElementById('aiimage').setAttribute('src', "Public/images/aioff.png");
                  $scope.changeState();
                  //document.getElementById('ai_curical').className=""
                }


                console.log("ai modify data:" + JSON.stringify($scope.localDeviceAIStatus));

                //debugger;
                break;
              }
              else {
                $scope.AiStatusCheck = "2"
              }
            }
            localStorage.setItem("localDeviceAIStatusAll", JSON.stringify($responddatastatus.data));
            $scope.localDeviceAIStatusAll = JSON.parse(localStorage.getItem('localDeviceAIStatusAll'));
            $scope.aiStatusShow = false;
            console.log("ai modify data:" + JSON.stringify($scope.localDeviceAIStatusAll));
            //debugger;

          }
          else {
            $scope.aiStatusShow = true;
          }
        }
        else {
          $scope.AiStatusCheck = "3"

        }


      });
  }
  function updatedeviceAIStatus(reqObj) {
    var jsonObj = {
      user_id: $scope.localuserinfo.user_id,
      token: $scope.webToken,
      reqObject: reqObj
    }

    $http.post($scope.localurlBase + '/ai/updateAIConfigLine', jsonObj)
      .then(function (response) {
        if (response.data.status == "1") {
          GetdeviceAIStatus($scope.localuserinfo.device_b_one_id, $scope.localuserinfo.hub_id)
        }
        else {
          $scope.loginAlertMessage = false;
          $scope.notiError = true;
          $scope.notiErrorshow = false;
          $scope.notiErrorMessage = response.data.message;
        }


      });
  }







  function deviceView() {
    //debugger;
    $scope.clickedDevice = {
      'device_b_one_id': $scope.localuserinfo.device_b_one_id,
      'category_id': $scope.localuserinfo.category_id,
      'navigation_from': 0
    }
    localStorage.setItem("localDeviceKey", JSON.stringify($scope.clickedDevice));
    $scope.localDeviceKey = JSON.parse(localStorage.getItem('localDeviceKey'));
    $scope.device_b_one_id = $scope.localDeviceKey.device_b_one_id;
    $scope.localClickedDevice = {
      "device_b_one_id": $scope.localDeviceKey.device_b_one_id,
      'category_id': $scope.localDeviceKey.category_id,
      'navigation_from': 0
    };
    console.log("datadevice check :-" + JSON.stringify($scope.localClickedDevice));
    $scope.getDeviceLatestStatus();


  }


});